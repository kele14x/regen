# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['regen']

package_data = \
{'': ['*'], 'regen': ['templates/*']}

install_requires = \
['Jinja2>=3.0.1,<4.0.0']

entry_points = \
{'console_scripts': ['pelican = regen.__main__:main']}

setup_kwargs = {
    'name': 'regen',
    'version': '0.1.0',
    'description': 'Tool for automatically generating HDL register slave module',
    'long_description': "# REGEN\n\nREGEN is a tool for automatically generating HDL register slave module. Currently, it's designed for [AXI4-Lite](https://en.wikipedia.org/wiki/Advanced_eXtensible_Interface) interface. It can easily generate a SystemVerilog (*.sv*) module from a description file, omitting the effort of writing the redundancy and error prone HDL codes by yourself.\n\nThis project is inspired by some public tool like [airhdl](https://airhdl.com) and similar proprietary tool I have used. The idea is that the tool can read an easy-to-edit description file, and parse it into an SystemVerilog template. The description file holds the detail of registers/fields for the register block. It also could generate C header (*.h*) file for software use, as well as a Word file (*.docx*) as document for the software-hardware interface description. At least my personal FPGA projects will benefit from this tool.\n\nIt's not complex, I'm slowly making it function basically. But beware that currently this project is still work in progress and may not work at all.\n",
    'author': 'Michiru Morishita',
    'author_email': 'kokser.merio@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/kele14x/regen',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
